# SovPlace — governance-aware placement for data spaces

Reference implementation of the model, the feasibility test, the placement
search, the exact integer program and the experiments of

> *Sovereign by Placement: A Lattice Model for Governance-Aware Deployment of
> Data Spaces in the Edge–Cloud Continuum.*

## Status of this package

Implementation of the paper's model and algorithms. It produces every table
and figure of the evaluation section: the case studies (Tables II and III,
Figure 3) and the synthetic experiments (Figure 4, Table IV). The output used
in the paper is in `results/`.

The data-space cost per boundary data request is one measured value for every
policy level: 0.5 ms at the median and 24.0 ms at the 99th percentile
(`sovplace/model.py`), taken from the testbed data in the repository root.

## Contents

```
sovplace/model.py         components, hops, functions, node types, parameters (Sec. III)
sovplace/feasibility.py   U_K by union-find, hosts(B), feasibility test, conflict certificate (Sec. IV)
sovplace/cost.py          hop classes, latency, budgets, violations, partition semantics (Sec. III-D, V-A)
sovplace/search.py        Algorithm 1 with incremental evaluation (Sec. V-D)
sovplace/ilp.py           exact integer program over the atoms of U_K, HiGHS via SciPy (Sec. V-C)
sovplace/enumerate.py     enumeration of the admissible region with down-set pruning
sovplace/baselines.py     Practice, Cloud-first, Tech-only
sovplace/cases.py         PV, FLOOD, ED-mono, ED-fed
sovplace/generator.py     synthetic federations (base and hard)
scripts/run_cases.py        Tables II and III
scripts/run_sensitivity.py  Figure 3
scripts/run_scaling.py      Figure 4 and Table IV, one part per call
scripts/check_exact.py      integer program against exhaustive enumeration
tests/test_core.py          regression tests
results/                    output of the three scripts
```

## Running

```
pip install -r requirements.txt        # Python 3.10+, NumPy, SciPy (bundles HiGHS)
python3 tests/test_core.py             # 4/4 expected, under 5 s
python3 scripts/run_cases.py           # a few seconds
python3 scripts/run_sensitivity.py     # a few seconds
for p in feas enum small medium large largeh large2 large3 search; do
  python3 scripts/run_scaling.py $p      # large2/large3: up to 10 min each
done
python3 scripts/check_exact.py
```

No network access and no data files are needed.

## What the tests establish

* **Theorem 1, independently of its proof.** On 40 random instances the
  feasibility test and exhaustive enumeration give the same answer.
* **Invariant.** Every placement returned by the search is admissible, and the
  incrementally maintained cost equals a full re-evaluation.
* **Exactness of the integer program.** On small instances its optimum equals
  the optimum found by enumerating every admissible partition under every
  allocation; the search never beats it.

## Parameters

`sovplace/model.py` holds the data-space cost (one measured value for every
policy level) and the assumed round trips and envelopes (Table I). Component demands follow
Section VI-A.

## Limitations

* One resource dimension (cores); node types are elastic, including edge
  gateways (see the paper's threats to validity).
* `enumerate.py` with `optimum=True` tries every allocation of every admissible
  partition and is meant for small instances only; on the case studies the
  optimum is taken from the integer program.
