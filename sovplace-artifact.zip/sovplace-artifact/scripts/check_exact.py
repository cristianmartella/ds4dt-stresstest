"""ILP against exhaustive enumeration (every admissible partition under every allocation)."""
import os, sys, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sovplace.generator import generate
from sovplace.ilp import solve_ilp
from sovplace.cost import evaluate
from sovplace.enumerate import enumerate_admissible
res = []
for n in (7, 8, 9):
    for seed in range(10):
        inst = generate(n, seed=seed)
        try:
            en = enumerate_admissible(inst, optimum=True, max_alloc=200_000)
        except RuntimeError:
            continue
        sol = solve_ilp(inst); ev = evaluate(inst, sol["node_of"], sol["type_of"])
        res.append((n, seed, ev["met"] == en["met"] and abs(ev["W"] - en["W"]) < 1e-6))
print(f"ILP = enumeration on {sum(r[2] for r in res)}/{len(res)} instances with 7-9 components")
json.dump(res, open("results/exact_check.json", "w"))
