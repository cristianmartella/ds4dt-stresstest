"""Figure 4 and Table IV: scalability and optimality on synthetic federations.

python3 scripts/run_scaling.py <part>   with part in feas, enum, small, medium, large, search
Each part writes results/scaling_<part>.json and prints a log."""
import json, os, statistics, sys, time
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from sovplace.generator import generate
from sovplace.feasibility import feasibility, Hosting
from sovplace.search import search
from sovplace.ilp import solve_ilp
from sovplace.cost import evaluate

part = sys.argv[1]
out = []


def naive_enumeration(inst):
    """Visit every partition of C (restricted-growth strings) and test it; no lattice structure."""
    n = len(inst.components)
    h = Hosting(inst)
    a = [0] * n
    found = False

    def leaf():
        blocks = {}
        for c, b in enumerate(a):
            blocks.setdefault(b, []).append(c)
        if any(a[x] != a[y] for x, y, _ in inst.K):
            return False
        return all(h.hosts(cs) for cs in blocks.values())

    def rec(i, m):
        nonlocal found
        if i == n:
            found = found or leaf()
            return
        for b in range(m + 1):
            a[i] = b
            rec(i + 1, max(m, b + 1))
    rec(1, 1)
    return found


if part == "feas":
    for n in (100, 1000, 10_000, 100_000, 1_000_000):
        inst = generate(n, seed=1, feasible=False)
        t0 = time.perf_counter(); ok, _, _ = feasibility(inst); t = (time.perf_counter() - t0) * 1e3
        out.append({"n": n, "ms": t, "feasible": ok}); print(f"test n={n} {t:.2f} ms feasible={ok}", flush=True)
elif part == "enum":
    for n in range(6, 13):
        worst, agree, total = 0.0, 0, 0
        for seed in range(40):
            inst = generate(n, seed=seed, feasible=False, contract_frac=0.4)
            ok, _, _ = feasibility(inst)
            if ok:
                continue
            t0 = time.perf_counter(); found = naive_enumeration(inst); t = (time.perf_counter() - t0) * 1e3
            total += 1; agree += (found == ok); worst = max(worst, t)
            if total == 3:
                break
        out.append({"n": n, "worst_ms": worst, "agree": agree, "total": total})
        print(f"enum n={n} worst {worst:.1f} ms, agree {agree}/{total}", flush=True)
else:
    plans = {"small": [("base", n, 10) for n in (8, 12, 16, 20)],
             "medium": [("base", n, 3) for n in (50, 100, 200, 400)],
             "large": [("base", 1000, 3)],
             "largeh": [("hard", 1000, 3)],
             "large2": [("base", 2000, 1)],
             "large3": [("hard", 2000, 1)]}
    if part == "search":
        for kind in ("base", "hard"):
            for n in (1000, 10_000):
                ts = []
                for seed in range(3):
                    inst = generate(n, seed=seed, hard=(kind == "hard"))
                    t0 = time.perf_counter(); search(inst); ts.append(time.perf_counter() - t0)
                out.append({"kind": kind, "n": n, "s": ts}); print(f"search {kind} n={n} {[round(x,2) for x in ts]}", flush=True)
    else:
        LIMIT = float(os.environ.get("ILP_LIMIT", "600"))
        for kind, n, reps in plans[part]:
            ts, ti, dW, dB, status, opt = [], [], [], [], [], 0
            for seed in range(reps):
                inst = generate(n, seed=seed, hard=(kind == "hard"))
                t0 = time.perf_counter(); st, _ = search(inst); ts.append(time.perf_counter() - t0)
                es = evaluate(inst, *st.component_placement())
                t0 = time.perf_counter(); sol = solve_ilp(inst, time_limit=LIMIT); ti.append(time.perf_counter() - t0)
                ei = evaluate(inst, sol["node_of"], sol["type_of"])
                assert es["violations"] == (0, 0, 0, 0) and ei["violations"] == (0, 0, 0, 0)
                status.append(sol["status"])
                dW.append(100.0 * (es["W"] - ei["W"]) / ei["W"] if ei["W"] else 0.0)
                dB.append(es["met"] - ei["met"])
                opt += (es["met"] == ei["met"] and abs(es["W"] - ei["W"]) <= 1e-6 * max(1, ei["W"]))
            row = {"kind": kind, "n": n, "instances": reps, "search_s": ts, "ilp_s": ti, "status": status,
                   "dW": dW, "dB": dB, "search_optimal": opt, "functions": len(inst.functions)}
            out.append(row)
            print(f"{kind} n={n} x{reps} search med {statistics.median(ts):.4f}s ILP {[round(x,2) for x in ti]} "
                  f"{status} dW worst {max(dW, key=abs):+.3f}% dB {dB} opt {opt}/{reps}", flush=True)
os.makedirs("results", exist_ok=True)
json.dump(out, open(f"results/scaling_{part}.json", "w"), indent=1)
